function alignBlocks() {
  let blocks = document.querySelectorAll('div');
  blocks.forEach((block) => {
    block.setAttribute("dir", "auto");
    block.style.textAlign = "initial";
  })
}

let pageLoadInterval = setInterval(() => {
  if (document.querySelector('div.notion-page-content') !== null) {
    alignBlocks()
  }
}, 200)